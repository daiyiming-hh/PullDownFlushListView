package com.ilovecollege.daiyiming.pulldownflushlistview.View;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.graphics.Color;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.ilovecollege.daiyiming.pulldownflushlistview.R;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by daiyiming on 2015/6/22.
 */

public class PullDownFlushListView extends RelativeLayout implements View.OnTouchListener, AbsListView.OnScrollListener, AdapterView.OnItemClickListener {

    private final static int HANDLER_MESSAGE_CLOSE_WAIT_VIEW = 0;

    private ListView listView = null;
    private int yDistance = 0;
    private TextView tv_pullDownTag = null;
    private TextView tv_lastTime = null;
    private ImageView img_flushImageView = null;
    private boolean canFlush = false; //可以刷新
    private LinearLayout ll_flushViewContainer = null; //刷新的界面
    private LinearLayout ll_waitViewContainer = null; //等待界面
    private TextView footer = null; //尾部控件
    private TextView tv_waitTextView = null;
    private ImageView img_waitImageView = null;
    private ImageView img_waitReasonImageView = null;
    private boolean isAnimation = false; //是否处于动画状态

    private OnPullDownFlushListViewFlushListener flushListener = null;
    private OnPullDownFlushListViewItemClickListener itemClickListener = null;

    private int downX = 0, downY = 0;
    private int headerFlushHeight = 0;
    private int headerWaitHeight = 0;

    private boolean isFlushLocked = false; //组件是否上锁

    private Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case HANDLER_MESSAGE_CLOSE_WAIT_VIEW: {
                    ObjectAnimator animator = ObjectAnimator.ofFloat(listView, "translationY", yDistance, 0);
                    animator.setDuration(200);
                    animator.setInterpolator(new DecelerateInterpolator());
                    animator.addListener(new AnimatorListenerAdapter() {
                        @Override
                        public void onAnimationStart(Animator animation) {
                            isAnimation = true;
                            super.onAnimationStart(animation);
                        }
                        @Override
                        public void onAnimationEnd(Animator animation) {
                            ll_waitViewContainer.setVisibility(View.INVISIBLE);
                            ll_flushViewContainer.setVisibility(View.VISIBLE);
                            ll_waitViewContainer.setTag(false);
                            img_waitImageView.setVisibility(View.VISIBLE);
                            img_waitReasonImageView.setVisibility(View.GONE);
                            tv_waitTextView.setText("正在刷新");
                            isAnimation = false;
                            yDistance = 0;
                            super.onAnimationEnd(animation);
                        }
                    });
                    animator.start();
                }break;
            }
            super.handleMessage(msg);
        }
    };

    public interface OnPullDownFlushListViewItemClickListener {
        void OnPullDownFlushListViewItemClicked(View view, int positon);
    }

    public interface OnPullDownFlushListViewFlushListener {
        void OnPullDownFlushListViewFlush(); //刷新
        void OnPullDownFlushListViewLoadMore(); //加载更多
    }

    public PullDownFlushListView(Context context, AttributeSet attrs) {
        super(context, attrs);

        //填充下拉刷新界面
        RelativeLayout header = new RelativeLayout(context);
        headerFlushHeight = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 80, context.getResources().getDisplayMetrics());
        AbsListView.LayoutParams headViewParams = new AbsListView.LayoutParams(AbsListView.LayoutParams.MATCH_PARENT, AbsListView.LayoutParams.WRAP_CONTENT);
        header.setLayoutParams(headViewParams);

        //刷新界面
        ll_flushViewContainer = new LinearLayout(context);
        RelativeLayout.LayoutParams flushViewParams = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
        flushViewParams.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM, RelativeLayout.TRUE);
        flushViewParams.addRule(RelativeLayout.CENTER_HORIZONTAL, RelativeLayout.TRUE);
        ll_flushViewContainer.setLayoutParams(flushViewParams);
        ll_flushViewContainer.setOrientation(LinearLayout.HORIZONTAL);
        int flushViewContainerPadding = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 20, context.getResources().getDisplayMetrics());
        ll_flushViewContainer.setPadding(0, flushViewContainerPadding, 0, flushViewContainerPadding);
        header.addView(ll_flushViewContainer);

        img_flushImageView = new ImageView(context);
        int flushImageWidth = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 35, context.getResources().getDisplayMetrics());
        LinearLayout.LayoutParams flushImageParams = new LinearLayout.LayoutParams(flushImageWidth, flushImageWidth);
        flushImageParams.gravity = Gravity.CENTER_VERTICAL;
        img_flushImageView.setLayoutParams(flushImageParams);
        img_flushImageView.setImageResource(R.drawable.icon_pull_down);
        ll_flushViewContainer.addView(img_flushImageView);

        LinearLayout flushTextContainer = new LinearLayout(context);
        LinearLayout.LayoutParams flushTextParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 40, context.getResources().getDisplayMetrics()));
        flushTextParams.gravity = Gravity.CENTER_VERTICAL;
        flushTextContainer.setLayoutParams(flushTextParams);
        flushTextContainer.setOrientation(LinearLayout.VERTICAL);
        ll_flushViewContainer.addView(flushTextContainer);

        tv_pullDownTag = new TextView(context);
        LinearLayout.LayoutParams tagParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, 0);
        tagParams.weight = 1;
        tv_pullDownTag.setLayoutParams(tagParams);
        tv_pullDownTag.setTextColor(Color.parseColor("#9E9E9E"));
        tv_pullDownTag.setText("向下拖动 要你好看");
        tv_pullDownTag.setTextSize(16);
        tv_pullDownTag.setGravity(Gravity.TOP);
        flushTextContainer.addView(tv_pullDownTag);

        tv_lastTime = new TextView(context);
        LinearLayout.LayoutParams timeParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, 0);
        timeParams.weight = 1;
        tv_lastTime.setLayoutParams(timeParams);
        tv_lastTime.setTextColor(Color.parseColor("#9E9E9E"));
        SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm");
        tv_lastTime.setText("上次更新：" + dateFormat.format(new Date(System.currentTimeMillis())));
        tv_lastTime.setTextSize(14);
        tv_lastTime.setGravity(Gravity.BOTTOM);
        flushTextContainer.addView(tv_lastTime);

        //填充等待界面
        headerWaitHeight = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 52, getResources().getDisplayMetrics());
        ll_waitViewContainer = new LinearLayout(context);
        RelativeLayout.LayoutParams ll_waitViewContainerParams = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
        ll_waitViewContainerParams.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM, RelativeLayout.TRUE);
        ll_waitViewContainerParams.addRule(RelativeLayout.CENTER_HORIZONTAL, RelativeLayout.TRUE);
        ll_waitViewContainer.setLayoutParams(ll_waitViewContainerParams);
        ll_waitViewContainer.setOrientation(LinearLayout.HORIZONTAL);
        int waitViewContainerPadding = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 16, context.getResources().getDisplayMetrics());
        ll_waitViewContainer.setPadding(0, waitViewContainerPadding, 0, waitViewContainerPadding);
        header.addView(ll_waitViewContainer);

        RelativeLayout waitImageContainer = new RelativeLayout(context);
        LinearLayout.LayoutParams waitImageContainerParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        waitImageContainerParams.gravity = Gravity.CENTER_VERTICAL;
        waitImageContainer.setLayoutParams(waitImageContainerParams);
        ll_waitViewContainer.addView(waitImageContainer);

        int waitImageWidth = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 20, context.getResources().getDisplayMetrics());

        img_waitImageView = new ImageView(context);
        RelativeLayout.LayoutParams waitImageViewParams = new RelativeLayout.LayoutParams(waitImageWidth, waitImageWidth);
        img_waitImageView.setLayoutParams(waitImageViewParams);
        img_waitImageView.setImageResource(R.drawable.icon_circle_wait_progress_gray);
        waitImageContainer.addView(img_waitImageView);

        img_waitReasonImageView = new ImageView(context);
        RelativeLayout.LayoutParams waitImageReasonViewParams = new RelativeLayout.LayoutParams(waitImageWidth, waitImageWidth);
        img_waitReasonImageView.setLayoutParams(waitImageReasonViewParams);
        img_waitReasonImageView.setImageResource(R.drawable.icon_flush_success);
        img_waitReasonImageView.setVisibility(View.GONE);
        waitImageContainer.addView(img_waitReasonImageView);

        tv_waitTextView = new TextView(context);
        tv_waitTextView.setText("正在加载");
        tv_waitTextView.setTextColor(Color.parseColor("#9E9E9E"));
        tv_waitTextView.setTextSize(18);
        LinearLayout.LayoutParams waitTextViewParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        waitTextViewParams.gravity = Gravity.CENTER_VERTICAL;
        waitTextViewParams.leftMargin = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 16, context.getResources().getDisplayMetrics());
        tv_waitTextView.setLayoutParams(waitTextViewParams);
        ll_waitViewContainer.addView(tv_waitTextView);

        //填充尾部
        footer = new TextView(context);
        AbsListView.LayoutParams footerParams = new AbsListView.LayoutParams(AbsListView.LayoutParams.MATCH_PARENT, (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 50, context.getResources().getDisplayMetrics()));
        footer.setLayoutParams(footerParams);
        footer.setText("内容加载中...");
        footer.setTextColor(Color.parseColor("#9E9E9E"));
        footer.setTextSize(16);
        footer.setGravity(Gravity.CENTER);

        ObjectAnimator circleViewRotation = ObjectAnimator.ofFloat(img_waitImageView, "rotation", 0, -360);
        circleViewRotation.setDuration(1000);
        circleViewRotation.setRepeatCount(-1);
        circleViewRotation.setRepeatMode(ObjectAnimator.INFINITE);
        circleViewRotation.setInterpolator(new LinearInterpolator());
        circleViewRotation.start();

        listView = new ListView(context);
        LayoutParams listViewParams = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
        listViewParams.topMargin = 0 - headerFlushHeight;
        listView.setLayoutParams(listViewParams);
        listView.setOverScrollMode(ListView.OVER_SCROLL_NEVER);
        this.addView(listView);

        ll_waitViewContainer.setVisibility(View.INVISIBLE);
        ll_waitViewContainer.setTag(false); //未显示

        header.setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                return true;
            }
        });

        footer.setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                return true;
            }
        });

        //用于精确控制下拉刷新
        View headerLine = new View(context);
        AbsListView.LayoutParams headerLineParams = new AbsListView.LayoutParams(AbsListView.LayoutParams.MATCH_PARENT, 0);
        headerLine.setLayoutParams(headerLineParams);

        listView.setDividerHeight(0);
        listView.addHeaderView(headerLine);
        listView.addHeaderView(header);
        listView.addFooterView(footer);
        listView.setOnScrollListener(this);
        listView.setOnItemClickListener(this);
        listView.setOnTouchListener(this);

    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        if (!isAnimation && listView.getFirstVisiblePosition() == 0) {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN: {
                    downX = (int) event.getX();
                    downY = (int) event.getY();
                }
                case MotionEvent.ACTION_MOVE: {
                    int moveX = (int) event.getX();
                    int moveY = (int) event.getY();

                    //下拉刷新判断
                    if (moveY >= downY && moveY - downY >= Math.abs(moveX - downX)) {
                        LayoutParams params = (LayoutParams) listView.getLayoutParams();
                        ObjectAnimator animator = null;
                        if (!(Boolean) ll_waitViewContainer.getTag()) {
                            yDistance = (moveY - downY) / 2;
                            animator = ObjectAnimator.ofFloat(listView, "translationY", 0, (moveY - downY) / 2);
                        } else {
                            yDistance = (moveY - downY) / 2 + headerWaitHeight;
                            animator = ObjectAnimator.ofFloat(listView, "translationY", 0, (moveY - downY) / 2 + headerWaitHeight);
                        }
                        animator.setDuration(0);
                        animator.start();
                        listView.setLayoutParams(params);
                        if (yDistance >= headerFlushHeight) {
                            tv_pullDownTag.setText("松开手指 立即刷新");
                            img_flushImageView.setRotation(180);
                        } else {
                            tv_pullDownTag.setText("向下拖动 要你好看");
                            img_flushImageView.setRotation(0);
                        }
                        if (yDistance > 0) {
                            return true;
                        }
                    }
                }break;
                case MotionEvent.ACTION_UP: {
                    if (listView.getFirstVisiblePosition() == 0) {
                        int end = 0;
                        if (yDistance >= headerFlushHeight) {
                            canFlush = true;
                            end = headerWaitHeight;
                        }
                        if ((Boolean) ll_waitViewContainer.getTag()) {
                            end = headerWaitHeight;
                        }
                        final int finalEnd = end;
                        ObjectAnimator animator = ObjectAnimator.ofFloat(listView, "translationY", yDistance, finalEnd);
                        animator.setDuration(200);
                        animator.setInterpolator(new DecelerateInterpolator());
                        animator.addListener(new AnimatorListenerAdapter() {
                            @Override
                            public void onAnimationStart(Animator animation) {
                                if (canFlush) {
                                    ll_waitViewContainer.setVisibility(View.VISIBLE);
                                    ll_waitViewContainer.setTag(true);
                                    ll_flushViewContainer.setVisibility(View.INVISIBLE);
                                    isAnimation = true;
                                }
                                super.onAnimationStart(animation);
                            }

                            @Override
                            public void onAnimationEnd(Animator animation) {
                                if (canFlush && flushListener != null && !isFlushLocked) { //刷新
                                    flushListener.OnPullDownFlushListViewFlush();
                                }
                                canFlush = false;
                                isAnimation = false;
                                yDistance = finalEnd;
                                super.onAnimationEnd(animation);
                            }
                        });
                        animator.start();
                    }
                }break;
            }
        }
        return false;
    }

    @Override
    public void onScrollStateChanged(AbsListView view, int scrollState) {

    }

    @Override
    public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
        if (firstVisibleItem + visibleItemCount == totalItemCount && flushListener != null && listView.getAdapter().getCount() > 2 && !isFlushLocked) { //加载更多
            flushListener.OnPullDownFlushListViewLoadMore();
        }
    }

    public void setOnPullDownFlushListViewFlushListener(OnPullDownFlushListViewFlushListener flushListener) {
        this.flushListener = flushListener;
    }

    public void setOnPullDownFlushListViewItemClickListener(OnPullDownFlushListViewItemClickListener itemClickListener) {
        this.itemClickListener = itemClickListener;
    }

    public void setLastFlushTime(long time) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm");
        tv_lastTime.setText("上次更新：" + dateFormat.format(new Date(time)));
    }

    public void showSuccessWaitView() {
        img_waitImageView.setVisibility(View.GONE);
        img_waitReasonImageView.setVisibility(View.VISIBLE);
        img_waitReasonImageView.setImageResource(R.drawable.icon_flush_success);
        tv_waitTextView.setText("更新成功");
        handler.sendEmptyMessageDelayed(HANDLER_MESSAGE_CLOSE_WAIT_VIEW, 1000);
    }

    //防止下拉刷新和上拉加载更多同时执行
    public void lockFlush() {
        isFlushLocked = true;
    }
    
    public void unLockFlush() {
        isFlushLocked = false;
    }

    public void setAdapter(ListAdapter adapter) {
        listView.setAdapter(adapter);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        if (position < 2 || position == (listView.getAdapter().getCount() - 1)) { //点击头尾
            return;
        }
        if (itemClickListener != null && yDistance == 0) { //且未处于拉伸状态
            itemClickListener.OnPullDownFlushListViewItemClicked(view, position - 2);
        }
    }

}
