package com.ilovecollege.daiyiming.pulldownflushlistview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import com.ilovecollege.daiyiming.pulldownflushlistview.View.PullDownFlushListView;

public class MainActivity extends AppCompatActivity implements PullDownFlushListView.OnPullDownFlushListViewFlushListener {

    private PullDownFlushListView pdflv_list = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();
    }

    private void init() {
        pdflv_list = (PullDownFlushListView) findViewById(R.id.pdflv_list);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_expandable_list_item_1, new String[]{"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"});
        pdflv_list.setAdapter(adapter);
        pdflv_list.setOnPullDownFlushListViewFlushListener(this);
    }

    @Override
    public void OnPullDownFlushListViewFlush() {
        new Thread() {
            @Override
            public void run() {
                try {
                    sleep(2000);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            pdflv_list.showSuccessWaitView();
                        }
                    });
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }

    @Override
    public void OnPullDownFlushListViewLoadMore() {
        Toast.makeText(this, "加载更多", Toast.LENGTH_LONG).show();
    }
}
